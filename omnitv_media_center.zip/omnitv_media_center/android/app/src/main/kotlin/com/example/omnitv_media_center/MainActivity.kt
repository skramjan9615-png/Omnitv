package com.example.omnitv_media_center

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
