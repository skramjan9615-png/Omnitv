import 'package:flutter/material.dart';
import '../../core/constants/app_theme.dart';

class VirtualRemoteSheet extends StatelessWidget {
  final Function(int) onNumberPressed;
  final VoidCallback onChannelUp;
  final VoidCallback onChannelDown;
  final VoidCallback onMuteToggle;
  final VoidCallback onGuidePressed;
  final VoidCallback onFavPressed;

  const VirtualRemoteSheet({
    Key? key,
    required this.onNumberPressed,
    required this.onChannelUp,
    required this.onChannelDown,
    required this.onMuteToggle,
    required this.onGuidePressed,
    required this.onFavPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: AppTheme.stbSurface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 50,
            height: 5,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'VIRTUAL STB REMOTE',
            style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.5, color: Colors.white70),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _remoteBtn(Icons.power_settings_new, 'PWR', AppTheme.stbRed, () => Navigator.pop(context)),
              _remoteBtn(Icons.volume_off, 'MUTE', AppTheme.stbCard, onMuteToggle),
              _remoteBtn(Icons.dvr, 'GUIDE', AppTheme.stbCard, () {
                Navigator.pop(context);
                onGuidePressed();
              }),
              _remoteBtn(Icons.favorite, 'FAV', AppTheme.stbCard, () {
                Navigator.pop(context);
                onFavPressed();
              }),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  _remoteBtn(Icons.keyboard_arrow_up, 'CH +', AppTheme.stbCard, onChannelUp),
                  const SizedBox(height: 8),
                  _remoteBtn(Icons.keyboard_arrow_down, 'CH -', AppTheme.stbCard, onChannelDown),
                ],
              ),
              Column(
                children: [
                  for (var row in [[1, 2, 3], [4, 5, 6], [7, 8, 9]])
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: row.map((num) => Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.stbCard,
                              minimumSize: const Size(56, 44),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            onPressed: () => onNumberPressed(num),
                            child: Text('$num', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                          ),
                        )).toList(),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.stbCard,
                        minimumSize: const Size(56, 44),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: () => onNumberPressed(0),
                      child: const Text('0', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _remoteBtn(IconData icon, String label, Color bg, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 64,
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(
          children: [
            Icon(icon, size: 22, color: Colors.white),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
