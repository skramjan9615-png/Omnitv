import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../../../core/constants/app_theme.dart';
import '../../../data/models/channel_model.dart';

class VlcPlayerWidget extends StatefulWidget {
  final ChannelModel channel;
  final VoidCallback onChannelUp;
  final VoidCallback onChannelDown;

  const VlcPlayerWidget({
    Key? key,
    required this.channel,
    required this.onChannelUp,
    required this.onChannelDown,
  }) : super(key: key);

  @override
  State<VlcPlayerWidget> createState() => _VlcPlayerWidgetState();
}

class _VlcPlayerWidgetState extends State<VlcPlayerWidget> {
  VideoPlayerController? _controller;
  bool _isLoading = true;
  bool _hasError = false;
  String _errorText = '';
  bool _showControls = true;
  bool _isLocked = false;
  bool _isMuted = false;
  double _playbackSpeed = 1.0;
  int _aspectRatioIndex = 0;
  int _urlTryIndex = 0;
  late List<String> _streamUrls;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    _setupStreamList();
    _loadStream(_streamUrls[_urlTryIndex]);
  }

  @override
  void didUpdateWidget(covariant VlcPlayerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.channel.number != widget.channel.number ||
        oldWidget.channel.primaryUrl != widget.channel.primaryUrl) {
      _urlTryIndex = 0;
      _setupStreamList();
      _loadStream(_streamUrls[_urlTryIndex]);
    }
  }

  void _setupStreamList() {
    _streamUrls = [widget.channel.primaryUrl, ...widget.channel.backupUrls];
  }

  Future<void> _loadStream(String url) async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    await _controller?.dispose();
    final controller = VideoPlayerController.networkUrl(Uri.parse(url));
    _controller = controller;

    try {
      await controller.initialize();
      await controller.setLooping(true);
      await controller.play();
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
      if (_urlTryIndex < _streamUrls.length - 1) {
        _urlTryIndex++;
        _loadStream(_streamUrls[_urlTryIndex]);
      } else {
        if (mounted) {
          setState(() {
            _isLoading = false;
            _hasError = true;
            _errorText = 'Stream unavailable. Checked primary & backup URLs.';
          });
        }
      }
    }
  }

  void _seekRelative(int seconds) {
    if (_controller == null || !_controller!.value.isInitialized) return;
    final currentPos = _controller!.value.position;
    _controller!.seekTo(currentPos + Duration(seconds: seconds));
  }

  void _cycleSpeed() {
    final speeds = [1.0, 1.25, 1.5, 2.0, 0.5];
    final nextIdx = (speeds.indexOf(_playbackSpeed) + 1) % speeds.length;
    setState(() {
      _playbackSpeed = speeds[nextIdx];
    });
    _controller?.setPlaybackSpeed(_playbackSpeed);
  }

  double _getAspectRatio() {
    if (_controller == null || !_controller!.value.isInitialized) return 16 / 9;
    if (_aspectRatioIndex == 1) return 16 / 9;
    if (_aspectRatioIndex == 2) return 4 / 3;
    return _controller!.value.aspectRatio;
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => setState(() => _showControls = !_showControls),
      child: Container(
        color: Colors.black,
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (_controller != null && _controller!.value.isInitialized && !_hasError)
              AspectRatio(
                aspectRatio: _getAspectRatio(),
                child: VideoPlayer(_controller!),
              ),
            if (_isLoading)
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(color: AppTheme.stbRed),
                  const SizedBox(height: 10),
                  Text(
                    'Tuning CH ${widget.channel.number} • ${widget.channel.name}...',
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ],
              ),
            if (_hasError)
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.signal_wifi_connected_no_internet_4, color: AppTheme.stbRed, size: 42),
                    const SizedBox(height: 8),
                    Text(_errorText, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: AppTheme.stbRed),
                      onPressed: () {
                        _urlTryIndex = 0;
                        _loadStream(_streamUrls[0]);
                      },
                      icon: const Icon(Icons.refresh, size: 18),
                      label: const Text('Retry Stream'),
                    ),
                  ],
                ),
              ),
            if (_showControls) _buildOverlayControls(),
          ],
        ),
      ),
    );
  }

  Widget _buildOverlayControls() {
    if (_isLocked) {
      return Positioned(
        top: 12,
        left: 12,
        child: IconButton(
          icon: const Icon(Icons.lock, color: AppTheme.stbRed, size: 28),
          onPressed: () => setState(() => _isLocked = false),
        ),
      );
    }

    return Container(
      color: Colors.black45,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.stbRed,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    'CH ${widget.channel.number}',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    widget.channel.name,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppTheme.stbAccentGreen,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text(
                    'LIVE',
                    style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 10),
                  ),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.skip_previous, color: Colors.white, size: 30),
                onPressed: widget.onChannelDown,
              ),
              IconButton(
                icon: const Icon(Icons.replay_10, color: Colors.white, size: 30),
                onPressed: () => _seekRelative(-10),
              ),
              IconButton(
                icon: Icon(
                  (_controller != null && _controller!.value.isPlaying)
                      ? Icons.pause_circle_filled
                      : Icons.play_circle_filled,
                  color: AppTheme.stbRed,
                  size: 48,
                ),
                onPressed: () {
                  if (_controller == null) return;
                  setState(() {
                    _controller!.value.isPlaying ? _controller!.pause() : _controller!.play();
                  });
                },
              ),
              IconButton(
                icon: const Icon(Icons.forward_10, color: Colors.white, size: 30),
                onPressed: () => _seekRelative(10),
              ),
              IconButton(
                icon: const Icon(Icons.skip_next, color: Colors.white, size: 30),
                onPressed: widget.onChannelUp,
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.lock_open, size: 20),
                  onPressed: () => setState(() => _isLocked = true),
                ),
                IconButton(
                  icon: Icon(_isMuted ? Icons.volume_off : Icons.volume_up, size: 20),
                  onPressed: () {
                    setState(() => _isMuted = !_isMuted);
                    _controller?.setVolume(_isMuted ? 0.0 : 1.0);
                  },
                ),
                TextButton(
                  onPressed: _cycleSpeed,
                  child: Text('${_playbackSpeed}x', style: const TextStyle(color: Colors.white, fontSize: 12)),
                ),
                TextButton(
                  onPressed: () => setState(() => _aspectRatioIndex = (_aspectRatioIndex + 1) % 3),
                  child: Text(
                    _aspectRatioIndex == 0 ? 'AUTO' : (_aspectRatioIndex == 1 ? '16:9' : '4:3'),
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
