import 'package:flutter/material.dart';
import '../../../core/constants/app_theme.dart';

class SettingsCenterScreen extends StatelessWidget {
  const SettingsCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        ListTile(
          leading: Icon(Icons.tv, color: AppTheme.stbRed),
          title: Text('TV & Channel Settings', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('Manage channel numbering & categories'),
        ),
        ListTile(
          leading: Icon(Icons.play_circle_fill, color: AppTheme.stbRed),
          title: Text('Player Settings', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('Hardware acceleration & buffers'),
        ),
      ],
    );
  }
}
