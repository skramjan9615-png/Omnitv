import 'package:flutter/material.dart';

class AppTheme {
  static const Color stbRed = Color(0xFFE50914);
  static const Color stbDarkBg = Color(0xFF080B12);
  static const Color stbSurface = Color(0xFF121824);
  static const Color stbCard = Color(0xFF1A2232);
  static const Color stbAccentGreen = Color(0xFF00E676);

  static ThemeData get cableTvTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: stbDarkBg,
      primaryColor: stbRed,
      colorScheme: const ColorScheme.dark(
        primary: stbRed,
        secondary: stbAccentGreen,
        surface: stbSurface,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: stbSurface,
        elevation: 0,
      ),
      cardTheme: CardThemeData(
        color: stbCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
