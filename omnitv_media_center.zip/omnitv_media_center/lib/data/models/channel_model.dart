class ChannelModel {
  int number;
  String name;
  String category;
  String logoUrl;
  String primaryUrl;
  List<String> backupUrls;
  String currentProgram;
  String nextProgram;
  bool isFavorite;
  bool isLocked;
  bool isEnabled;

  ChannelModel({
    required this.number,
    required this.name,
    required this.category,
    this.logoUrl = '',
    required this.primaryUrl,
    this.backupUrls = const [],
    this.currentProgram = 'Live Broadcast',
    this.nextProgram = 'Upcoming Show',
    this.isFavorite = false,
    this.isLocked = false,
    this.isEnabled = true,
  });
}

final List<ChannelModel> defaultChannels = [
  ChannelModel(
    number: 101,
    name: 'Omni News 24 HD',
    category: 'News',
    primaryUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    backupUrls: ['https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'],
    currentProgram: 'Prime Time Headlines',
    nextProgram: 'World Tonight @ 22:00',
    isFavorite: true,
  ),
  ChannelModel(
    number: 102,
    name: 'Global Bharat News',
    category: 'News',
    primaryUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    currentProgram: 'Evening Debate Live',
    nextProgram: 'Sports Roundup',
  ),
  ChannelModel(
    number: 201,
    name: 'Cinema Max HD',
    category: 'Movies',
    primaryUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    currentProgram: 'Big Buck Bunny (Blockbuster)',
    nextProgram: 'Action Mania',
    isFavorite: true,
  ),
  ChannelModel(
    number: 301,
    name: 'Beats Music TV',
    category: 'Music',
    primaryUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    currentProgram: 'Top 20 Chartbusters',
    nextProgram: 'Retro Night',
  ),
  ChannelModel(
    number: 401,
    name: 'Kids Toon World',
    category: 'Kids',
    primaryUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    currentProgram: 'Super Toon Adventures',
    nextProgram: 'Magic Hour',
  ),
  ChannelModel(
    number: 501,
    name: 'Super Sports 1 HD',
    category: 'Sports',
    primaryUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    currentProgram: 'Super League Live',
    nextProgram: 'Post-Match Analysis',
    isFavorite: true,
  ),
  ChannelModel(
    number: 601,
    name: 'Shanti Devotional',
    category: 'Devotional',
    primaryUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    currentProgram: 'Evening Aarti & Bhajans',
    nextProgram: 'Spiritual Discourse',
  ),
];
