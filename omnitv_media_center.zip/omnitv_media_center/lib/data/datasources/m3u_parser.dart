import '../models/channel_model.dart';

class M3UParser {
  static List<ChannelModel> parse(String content, {int startNumber = 701}) {
    final lines = content.split('\n');
    final List<ChannelModel> channels = [];
    String? currentName;
    String? currentGroup;
    String? currentLogo;
    int currentNum = startNumber;

    for (var rawLine in lines) {
      final line = rawLine.trim();
      if (line.startsWith('#EXTINF:')) {
        final groupMatch = RegExp(r'group-title="([^"]+)"').firstMatch(line);
        final logoMatch = RegExp(r'tvg-logo="([^"]+)"').firstMatch(line);
        currentGroup = groupMatch?.group(1) ?? 'Others';
        currentLogo = logoMatch?.group(1) ?? '';

        final commaIdx = line.lastIndexOf(',');
        if (commaIdx != -1 && commaIdx < line.length - 1) {
          currentName = line.substring(commaIdx + 1).trim();
        } else {
          currentName = 'Channel $currentNum';
        }
      } else if (line.isNotEmpty && !line.startsWith('#')) {
        channels.add(
          ChannelModel(
            number: currentNum++,
            name: currentName ?? 'Stream $currentNum',
            category: currentGroup ?? 'Others',
            logoUrl: currentLogo ?? '',
            primaryUrl: line,
            currentProgram: 'Live M3U Stream',
            nextProgram: 'Continuous Broadcast',
          ),
        );
        currentName = null;
        currentGroup = null;
        currentLogo = null;
      }
    }
    return channels;
  }
}
