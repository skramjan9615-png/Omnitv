import 'package:flutter/material.dart';
import 'core/constants/app_theme.dart';
import 'data/models/channel_model.dart';
import 'presentation/screens/player/vlc_player_widget.dart';
import 'presentation/screens/settings/settings_center_screen.dart';
import 'presentation/widgets/virtual_remote_sheet.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OmniTVApp());
}

class OmniTVApp extends StatelessWidget {
  const OmniTVApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OmniTV Set-Top Box',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.cableTvTheme,
      home: const MainStbShell(),
    );
  }
}

class MainStbShell extends StatefulWidget {
  const MainStbShell({super.key});

  @override
  State<MainStbShell> createState() => _MainStbShellState();
}

class _MainStbShellState extends State<MainStbShell> {
  int _currentNavIndex = 0;
  List<ChannelModel> _channels = [];
  int _currentChannelIndex = 0;

  @override
  void initState() {
    super.initState();
    _channels = List.from(defaultChannels);
  }

  ChannelModel get _activeChannel => _channels[_currentChannelIndex];

  void _channelUp() {
    setState(() {
      _currentChannelIndex = (_currentChannelIndex + 1) % _channels.length;
    });
  }

  void _channelDown() {
    setState(() {
      _currentChannelIndex = (_currentChannelIndex - 1 + _channels.length) % _channels.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.tv, color: AppTheme.stbRed),
            SizedBox(width: 8),
            Text('OmniTV STB', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
      body: _currentNavIndex == 0 ? Column(
        children: [
          SizedBox(
            height: 230,
            width: double.infinity,
            child: VlcPlayerWidget(
              channel: _activeChannel,
              onChannelUp: _channelUp,
              onChannelDown: _channelDown,
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _channels.length,
              itemBuilder: (ctx, idx) {
                final ch = _channels[idx];
                return ListTile(
                  title: Text(ch.name),
                  subtitle: Text('CH: ${ch.number} | ${ch.category}'),
                  onTap: () => setState(() => _currentChannelIndex = idx),
                );
              },
            ),
          ),
        ],
      ) : const SettingsCenterScreen(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentNavIndex,
        onTap: (idx) => setState(() => _currentNavIndex = idx),
        backgroundColor: AppTheme.stbSurface,
        selectedItemColor: AppTheme.stbRed,
        unselectedItemColor: Colors.white60,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home / Live TV'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}
